import React from "react";
import { useState, useEffect } from "react";
import { Switch, Link, useParams, Route } from "react-router";
import UserRow from "./UserRow";
import SingleUser from "./SingleUser";

function TableAllUsers() {
  const [Users, setusers] = useState([]);

  useEffect(() => {
    fetch("http://localhost:3000/api/users")
      .then((response) => response.json())
      .then((data) => {
        setusers(data.data);
      });
  });
  return (
    /* <!-- DataTales Example --> */
    <div className="card shadow mb-4">
      <div className="card-body">
        <div className="table-responsive">
          <table
            className="table table-bordered"
            id="dataTable"
            width="100%"
            cellSpacing="0"
          >
            <thead>
              <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Correo</th>
                <th>Detail</th>
              </tr>
            </thead>
            <tfoot>
              <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Correo</th>
                <th>Detail</th>
              </tr>
            </tfoot>
            <tbody>
              {Users.map((row, i) => {
                return <UserRow {...row} key={i} />;
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default TableAllUsers;
