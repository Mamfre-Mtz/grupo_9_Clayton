import React from "react";
import image from "../assets/images/mexicangeek.png";
import ContentWrapper from "./ContentWrapper";
import TableUsers from "./TableAllUsers";
import TableProducts from "./TableAllProducts";
import LastComicInDb from "./LastComicInDb";
import ContentRowMovies from "./ContentRowTotals";
import SearchMovies from "./SearchMovies";
import NotFound from "./NotFound";
import { Link, Route, Switch } from "react-router-dom";
import SingleUser from "./SingleUser";

function SideBar() {
  return (
    <React.Fragment>
      {/*<!-- Sidebar -->*/}
      <ul
        className="navbar-nav mg-sidebar sidebar sidebar-dark accordion"
        id="accordionSidebar"
      >
        {/*<!-- Sidebar - Brand -->*/}
        <a
          className="sidebar-brand d-flex align-items-center justify-content-center"
          href="/"
        >
          <div className="sidebar-brand-icon">
            <img className="w-100" src={image} alt="Digital House" />
          </div>
        </a>
        {/*<!-- Divider -->*/}
        <hr className="sidebar-divider my-0" />
        {/*<!-- Nav Item - Dashboard -->*/}
        <li className="nav-item active">
          <Link className="nav-link" to="/">
            <i className="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard - Mexican Geek</span>
          </Link>
        </li>
        {/*<!-- Divider -->*/}
        <hr className="sidebar-divider" />
        {/*<!-- Heading -->*/}
        <div className="sidebar-heading">Actions</div>
        {/*<!-- Nav Item - Pages -->*/}
        <li className="nav-item">
          <Link className="nav-link" to="/TableUsers">
            <i className="fas fa-fw fa-folder"></i>
            <span>Users</span>
          </Link>
        </li>
        {/*<!-- Nav Item - Charts -->*/}
        <li className="nav-item">
          <Link className="nav-link" to="/TableProducts">
            <i className="fas fa-fw fa-folder"></i>
            <span>products</span>
          </Link>
        </li>
        {/* 
        {/*<!-- Nav Item - Tables -->/}
        <li className="nav-item nav-link">
          <Link className="nav-link" to="/ContentRowMovies">
            <i className="fas fa-fw fa-table"></i>
            <span>Tables</span>
          </Link>
        </li>{" "}
        */}
        {/*<!-- Divider -->*/}
        <hr className="sidebar-divider d-none d-md-block" />
      </ul>
      {/*<!-- End of Sidebar -->*/}

      {/*<!-- Microdesafio 1 -->*/}
      {/*<!--<Route exact path="/">
                <ContentWrapper />
            </Route>
            <Route path="/GenresInDb">
                <GenresInDb />
            </Route>
            <Route path="/LastMovieInDb">
                <LastMovieInDb />
            </Route>
            <Route path="/ContentRowMovies">
                <ContentRowMovies />
            </Route>*/}
      {/*<!-- End Microdesafio 1 -->*/}

      {/*<!-- End Microdesafio 2 -->*/}
      <Switch>
        <Route exact path="/">
          <ContentWrapper />
        </Route>
        <Route path="/TableUsers">
          <TableUsers />
        </Route>
        <Route path="/TableProducts">
          <TableProducts />
        </Route>
        <Route path="/ContentRowMovies">
          <ContentRowMovies />
        </Route>
        <Route path="/checkuser/:id">
          <SingleUser />
        </Route>
        <Route component={NotFound} />
      </Switch>
      {/*<!-- End Microdesafio 2 -->*/}
    </React.Fragment>
  );
}
export default SideBar;
