import React from "react";
import LastComicInDb from "./LastComicInDb";
import WritersInDb from "./WritersInDb";

function ContentRowCenter() {
  return (
    <div className="row">
      {/*<!-- Last Movie in DB -->*/}
      <LastComicInDb />
      {/*<!-- End content row last movie in Data Base -->*/}

      {/*<!-- Genres in DB -->*/}
      <WritersInDb />
    </div>
  );
}

export default ContentRowCenter;
