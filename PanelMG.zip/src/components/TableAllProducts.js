import React from "react";
import { useState, useEffect } from "react";
import RowEditorialTotals from "./RowEditorialTotals";
import ProductRow from "./ProductRow";

function TableAllUsers() {
  const [Products, setproducts] = useState([]);
  const [Category, setcategory] = useState([]);

  useEffect(() => {
    fetch("http://localhost:3000/api/products")
      .then((response) => response.json())
      .then((data) => {
        setproducts(data.comics);
        setcategory(data.category);
      });
  });
  return (
    /* <!-- DataTales Example --> */
    <div className="ml-4">
      <div className="mt-4 ml-2">
        <RowEditorialTotals />
      </div>
      <div className="card shadow mb-4">
        <div className="card-body">
          <div className="table-responsive">
            <table
              className="table table-bordered"
              id="dataTable"
              width="100%"
              cellSpacing="0"
            >
              <thead>
                <tr>
                  <th>Título</th>
                  <th>Escritor</th>
                  <th>Editorial</th>
                  <th>Cover</th>
                </tr>
              </thead>
              <tfoot>
                <tr>
                  <th>ID</th>
                  <th>Escritor</th>
                  <th>Editorial</th>
                  <th>Cover</th>
                </tr>
              </tfoot>
              <tbody>
                {Products.map((row, i) => {
                  return <ProductRow {...row} key={i} />;
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

export default TableAllUsers;
