import React from "react";
import { useState, useEffect } from "react";
import SmallCard from "./SmallCard";

/*  Cada set de datos es un objeto literal */
function RowEditorialTotals() {
  const [listadoImg, setImg] = useState([]);
  const [listadoDC, setDc] = useState([]);
  const [listadoMarvel, setMarvel] = useState([]);

  useEffect(() => {
    fetch("http://localhost:3000/api/products")
      .then((response) => response.json())
      .then((data) => {
        setImg(data.category[0].count);
        setDc(data.category[1].count);
        setMarvel(data.category[2].count);
      })
      .catch((error) => console.log(error));
  });

  /* <!-- Products in DB --> */
  let cartProps = [
    {
      title: "Image Comics",
      color: "dark",
      cuantity: listadoImg,
      icon: "fa-id-badge",
    },

    /* <!-- Users awards --> */

    {
      title: "DC Comics",
      color: "primary",
      cuantity: listadoDC,
      icon: "fa-id-badge",
    },

    /* <!-- Actors quantity --> */

    {
      title: "Marvel Comics",
      color: "danger",
      cuantity: listadoMarvel,
      icon: "fa-id-badge",
    },
  ];

  return (
    <div className="row">
      {cartProps.map((movie, i) => {
        return <SmallCard {...movie} key={i} />;
      })}
    </div>
  );
}

export default RowEditorialTotals;
