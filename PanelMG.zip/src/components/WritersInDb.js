import React from "react";
import { useState, useEffect } from "react";
import TableBlock from "./TableBlock";
function WritersInDb() {
  const [writerBlock, setWriters] = useState([]);

  useEffect(() => {
    fetch("http://localhost:3000/api/products/writer")
      .then((response) => response.json())
      .then((data) => {
        setWriters(data.writers);
      })
      .catch((error) => console.log(error));
  });

  return (
    <div className="col-lg-6 mb-4">
      <div className="card shadow mb-4">
        <div className="card-header py-3">
          <h5 className="m-0 font-weight-bold text-gray-800">
            Writers in Data Base
          </h5>
        </div>
        <div className="card-body">
          <div className="row">
            {writerBlock.map((writer, i) => {
              return <TableBlock {...writer} key={i} />;
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

export default WritersInDb;
