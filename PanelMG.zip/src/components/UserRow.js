import React from "react";

function UserRow(props) {
  return (
    <tr>
      <td>{props.id}</td>
      <td>{props.name}</td>
      <td>{props.email}</td>
      <td>
        <a href={`${props.detail}`}>{props.detail}</a>
      </td>
    </tr>
  );
}

export default UserRow;
