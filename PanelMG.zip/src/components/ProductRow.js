import React from "react";

function ProductRow(props) {
  return (
    <tr>
      <td>{props.name}</td>
      <td>{props.writer}</td>
      <td>{props.editorial}</td>
      <td>
        <a
          href={`http://localhost:3001/assets/img/comicIssues/${props.cover}`}
          target="_blank"
        >
          {props.cover}
        </a>
      </td>
    </tr>
  );
}

export default ProductRow;
