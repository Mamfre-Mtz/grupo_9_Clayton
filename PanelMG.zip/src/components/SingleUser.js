import React from "react";
import { useState, useEffect } from "react";
import { useParams } from "react-router";

function SingleUser() {
  const [User, setuser] = useState([]);
  const [uri, seturi] = useState(["http://localhost:3001/assets/img/users/"]);

  useEffect(() => {
    fetch(`http://localhost:3000/api/users/${id}`)
      .then((response) => response.json())
      .then((data) => {
        setuser(data);
      })
      .catch((error) => {
        console.log(error);
      });
  });
  let { id } = useParams();

  return (
    <div>
      <h2 class="mt-5 ml-4">User: {User.name}</h2>
      <h4 class="ml-4">Email: {User.email}</h4>
      <h4 class="ml-4">Birthday: {User.age}</h4>
      <h4 class="ml-4">City: {User.city}</h4>
      <h4 class="ml-4">
        Country: {User.country_id ? User.country_fk.name : "undefined"}
      </h4>
      <h4 class="ml-4">Address: {User.address}</h4>
      <h4 class="ml-4">cp: {User.cp}</h4>
      <h4 class="ml-4">
        <a
          href={`${User.avatar ? uri + User.avatar : uri + "Default.png"}`}
          target="_blank"
        >
          avatar: {User.avatar ? User.avatar : "Default"}
        </a>
      </h4>
    </div>
  );
}

export default SingleUser;
