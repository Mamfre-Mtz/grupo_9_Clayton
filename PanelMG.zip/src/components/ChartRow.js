import React from "react";

function ChartRow(props) {
  return (
    <tr>
      <td>{props.name}</td>
      <td>{props.available ? "Disponible" : "No disponible"}</td>
      <td>${props.price}</td>
      <td>{props.writer}</td>
      <td>{props.editorial}</td>
    </tr>
  );
}

export default ChartRow;
