import React from "react";
import { useState, useEffect } from "react";
import ChartRow from "./ChartRow";

function Chart() {
  const [comics, setcomics] = useState([]);

  useEffect(() => {
    fetch("http://localhost:3000/api/products")
      .then((response) => response.json())
      .then((data) => {
        setcomics(data.comics);
      });
  });
  return (
    /* <!-- DataTales Example --> */
    <div className="card shadow mb-4">
      <div className="card-body">
        <div className="table-responsive">
          <table
            className="table table-bordered"
            id="dataTable"
            width="100%"
            cellSpacing="0"
          >
            <thead>
              <tr>
                <th>Título</th>
                <th>Estatus</th>
                <th>Precio</th>
                <th>Escritor</th>
                <th>Editorial</th>
              </tr>
            </thead>
            <tfoot>
              <tr>
                <th>Título</th>
                <th>Estatus</th>
                <th>Precio</th>
                <th>Escritor</th>
                <th>Editorial</th>
              </tr>
            </tfoot>
            <tbody>
              {comics.map((row, i) => {
                return <ChartRow {...row} key={i} />;
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default Chart;
