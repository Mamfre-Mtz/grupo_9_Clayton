import React from "react";
import { useState, useEffect } from "react";
import SmallCard from "./SmallCard";

/*  Cada set de datos es un objeto literal */
function ContentRowTotals() {
  const [listadoUsers, setUsers] = useState([]);
  const [listadoProducts, setProducts] = useState([]);
  const [listadoEdit, setEdit] = useState([]);

  useEffect(() => {
    fetch("http://localhost:3000/api/users")
      .then((response) => response.json())
      .then((data) => {
        setUsers(data.meta.count);
      })
      .catch((error) => console.log(error));
  });

  useEffect(() => {
    fetch("http://localhost:3000/api/products")
      .then((response) => response.json())
      .then((data) => {
        setProducts(data.count);
      })
      .catch((error) => console.log(error));
  });

  useEffect(() => {
    fetch("http://localhost:3000/api/products/editorial")
      .then((response) => response.json())
      .then((data) => {
        setEdit(data.count);
      })
      .catch((error) => console.log(error));
  });

  /* <!-- Products in DB --> */
  let cartProps = [
    {
      title: "Products in Data Base",
      color: "primary",
      cuantity: listadoProducts,
      icon: "fa-clipboard-list",
    },

    /* <!-- Users awards --> */

    {
      title: " Users in Data Base",
      color: "success",
      cuantity: listadoUsers,
      icon: "fa-users",
    },

    /* <!-- Actors quantity --> */

    {
      title: "Editorials",
      color: "warning",
      cuantity: listadoEdit,
      icon: "fa-book-open",
    },
  ];

  return (
    <div className="row">
      {cartProps.map((movie, i) => {
        return <SmallCard {...movie} key={i} />;
      })}
    </div>
  );
}

export default ContentRowTotals;
